package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.RyzoraRepository
import com.example.ui.components.StatusBadge
import com.example.ui.screens.*
import com.example.ui.theme.*

enum class NavigationTab(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    OVERVIEW("Overview", Icons.Filled.Dashboard, Icons.Outlined.Dashboard),
    INBOX("Inbox", Icons.Filled.Forum, Icons.Outlined.Forum),
    ORDERS("Orders", Icons.Filled.LocalMall, Icons.Outlined.LocalMall),
    CATALOG("Catalog", Icons.Filled.Inventory2, Icons.Outlined.Inventory2),
    SIMULATOR("Simulator", Icons.Filled.PlayCircle, Icons.Outlined.PlayCircleOutline),
    DOCS("Setup", Icons.Filled.Settings, Icons.Outlined.Settings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val repository = RyzoraRepository.instance

        setContent {
            RyzoraTheme {
                MainAppScaffold(repository = repository)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScaffold(repository: RyzoraRepository) {
    var selectedTab by remember { mutableStateOf(NavigationTab.OVERVIEW) }
    val conversations by repository.conversations.collectAsState()
    val config by repository.businessConfig.collectAsState()

    val pendingEscalations = conversations.count { it.requiresHumanTakeover }

    // BackHandler: return to Overview if on another tab
    if (selectedTab != NavigationTab.OVERVIEW) {
        BackHandler {
            selectedTab = NavigationTab.OVERVIEW
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = ObsidianBlack,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(SurfaceCard),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "7R",
                                color = RyzoraCyan,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "RYZORA",
                                    color = TextPrimary,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "AI Agent",
                                    color = RyzoraCyan,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "Smart Choice. Better Life.",
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }
                },
                actions = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        StatusBadge(
                            text = if (config.isGlobalAiAutoReplyEnabled) "AI Live" else "AI Paused",
                            color = if (config.isGlobalAiAutoReplyEnabled) RyzoraEmerald else RyzoraRose
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SurfaceDark,
                    titleContentColor = TextPrimary
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = SurfaceDark,
                contentColor = TextSecondary,
                windowInsets = WindowInsets.navigationBars,
                tonalElevation = 8.dp
            ) {
                NavigationTab.entries.forEach { tab ->
                    val isSelected = selectedTab == tab
                    val hasBadge = tab == NavigationTab.INBOX && pendingEscalations > 0

                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (hasBadge) {
                                        Badge(
                                            containerColor = RyzoraAmber,
                                            contentColor = Color.Black
                                        ) {
                                            Text("$pendingEscalations", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                    contentDescription = tab.title,
                                    tint = if (isSelected) RyzoraCyan else TextSecondary
                                )
                            }
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) RyzoraCyan else TextSecondary
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = RyzoraCyan,
                            selectedTextColor = RyzoraCyan,
                            indicatorColor = RyzoraCyan.copy(alpha = 0.15f),
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                NavigationTab.OVERVIEW -> DashboardScreen(
                    repository = repository,
                    onNavigateToConversations = { selectedTab = NavigationTab.INBOX },
                    onNavigateToOrders = { selectedTab = NavigationTab.ORDERS },
                    onNavigateToSimulator = { selectedTab = NavigationTab.SIMULATOR }
                )
                NavigationTab.INBOX -> ConversationsScreen(repository = repository)
                NavigationTab.ORDERS -> OrdersScreen(repository = repository)
                NavigationTab.CATALOG -> ProductsScreen(repository = repository)
                NavigationTab.SIMULATOR -> WebhookSimulatorScreen(repository = repository)
                NavigationTab.DOCS -> AgentSettingsScreen(repository = repository)
            }
        }
    }
}
